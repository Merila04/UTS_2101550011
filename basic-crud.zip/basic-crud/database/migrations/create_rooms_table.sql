CREATE TABLE IF NOT EXISTS rooms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_number VARCHAR(10) NOT NULL,
    type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    status ENUM('available', 'occupied', 'maintenance') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_room_number (room_number),
    INDEX idx_type (type),
    INDEX idx_status (status)
); 

-- start dummy data
INSERT INTO rooms (room_number, type, price, status) VALUES
('101', 'Single', 100, 'available'),
('102', 'Double', 150, 'available'),
('103', 'Suite', 200, 'available'),
('104', 'Single', 100, 'available'),
('105', 'Double', 150, 'available'),
('106', 'Suite', 200, 'available');
-- end dummy data