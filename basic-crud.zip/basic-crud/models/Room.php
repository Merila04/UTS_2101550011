<?php

class Room {
    private $conn;
    private $table = "rooms";

    // Properties
    public $id;
    public $room_number;
    public $type;
    public $price;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Read all rooms
    public function read($search = '') {
        $query = "SELECT * FROM " . $this->table;
        
        if (!empty($search)) {
            $query .= " WHERE room_number LIKE :search OR type LIKE :search";
        }

        $stmt = $this->conn->prepare($query);

        if (!empty($search)) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(":search", $searchTerm);
        }

        $stmt->execute();
        return $stmt;
    }

    // Read single room
    public function readOne() {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();

        return $stmt;
    }

    // Create room
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                 (room_number, type, price, status) 
                 VALUES (:room_number, :type, :price, :status)";

        $stmt = $this->conn->prepare($query);

        // Sanitize input
        $this->room_number = htmlspecialchars(strip_tags($this->room_number));
        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->price = htmlspecialchars(strip_tags($this->price));
        $this->status = htmlspecialchars(strip_tags($this->status));

        // Bind parameters
        $stmt->bindParam(":room_number", $this->room_number);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":status", $this->status);

        return $stmt->execute();
    }

    // Update room
    public function update() {
        $query = "UPDATE " . $this->table . "
                 SET room_number = :room_number,
                     type = :type,
                     price = :price,
                     status = :status
                 WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize input
        $this->room_number = htmlspecialchars(strip_tags($this->room_number));
        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->price = htmlspecialchars(strip_tags($this->price));
        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind parameters
        $stmt->bindParam(":room_number", $this->room_number);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    // Delete room
    public function delete() {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    // Check if room exists
    public function exists() {
        $query = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['count'] > 0;
    }
} 