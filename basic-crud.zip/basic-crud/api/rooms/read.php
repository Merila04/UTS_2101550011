<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../../config/Database.php';
include_once '../../models/Room.php';

$database = new Database();
$db = $database->getConnection();

$room = new Room($db);

// Get search parameter
$search = isset($_GET['search']) ? $_GET['search'] : '';

$stmt = $room->read($search);
$num = $stmt->rowCount();

if($num > 0) {
    $rooms_arr = array();
    $rooms_arr["data"] = array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $room_item = array(
            "id" => $id,
            "room_number" => $room_number,
            "type" => $type,
            "price" => $price,
            "status" => $status
        );

        array_push($rooms_arr["data"], $room_item);
    }

    http_response_code(200);
    echo json_encode(array(
        "status" => "success",
        "message" => "Data retrieved successfully",
        "data" => $rooms_arr["data"]
    ));
} else {
    http_response_code(200);
    echo json_encode(array(
        "status" => "success",
        "message" => "No rooms found",
        "data" => array()
    ));
} 