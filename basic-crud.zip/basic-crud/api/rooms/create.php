<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/Database.php';
include_once '../../models/Room.php';

$database = new Database();
$db = $database->getConnection();

$room = new Room($db);

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->room_number) &&
    !empty($data->type) &&
    !empty($data->price) &&
    !empty($data->status)
){
    $room->room_number = $data->room_number;
    $room->type = $data->type;
    $room->price = $data->price;
    $room->status = $data->status;

    if($room->create()){
        http_response_code(201);
        echo json_encode(array(
            "status" => "success",
            "message" => "Room was created",
            "data" => array(
                "room_number" => $room->room_number,
                "type" => $room->type,
                "price" => $room->price,
                "status" => $room->status
            )
        ));
    } else {
        http_response_code(503);
        echo json_encode(array(
            "status" => "error",
            "message" => "Unable to create room",
            "data" => null
        ));
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        "status" => "error",
        "message" => "Unable to create room. Data is incomplete",
        "data" => null
    ));
} 