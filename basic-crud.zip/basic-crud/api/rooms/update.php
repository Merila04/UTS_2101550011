<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/Database.php';
include_once '../../models/Room.php';

$database = new Database();
$db = $database->getConnection();

$room = new Room($db);

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->id) &&
    !empty($data->room_number) &&
    !empty($data->type) &&
    !empty($data->price) &&
    !empty($data->status)
){
    $room->id = $data->id;
    
    if(!$room->exists()) {
        http_response_code(404);
        echo json_encode(array(
            "status" => "error",
            "message" => "Room not found",
            "data" => null
        ));
        exit();
    }

    $room->room_number = $data->room_number;
    $room->type = $data->type;
    $room->price = $data->price;
    $room->status = $data->status;

    if($room->update()){
        http_response_code(200);
        echo json_encode(array(
            "status" => "success",
            "message" => "Room was updated",
            "data" => array(
                "id" => $room->id,
                "room_number" => $room->room_number,
                "type" => $room->type,
                "price" => $room->price,
                "status" => $room->status
            )
        ));
    } else {
        http_response_code(503);
        echo json_encode(array(
            "status" => "error",
            "message" => "Unable to update room",
            "data" => null
        ));
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        "status" => "error",
        "message" => "Unable to update room. Data is incomplete",
        "data" => null
    ));
} 