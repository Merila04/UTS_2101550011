<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../../../config/Database.php';
include_once '../../../models/Room.php';

$database = new Database();
$db = $database->getConnection();

$room = new Room($db);

// Get ID dari parameter yang di-rewrite oleh .htaccess
$room->id = isset($_GET['id']) ? $_GET['id'] : die();

$stmt = $room->readOne();

if($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $room_arr = array(
        "id" => $row['id'],
        "room_number" => $row['room_number'],
        "type" => $row['type'],
        "price" => $row['price'],
        "status" => $row['status']
    );

    http_response_code(200);
    echo json_encode(array(
        "status" => "success",
        "message" => "Room found",
        "data" => $room_arr
    ));
} else {
    http_response_code(404);
    echo json_encode(array(
        "status" => "error",
        "message" => "Room not found",
        "data" => null
    ));
} 