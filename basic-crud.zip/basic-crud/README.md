# API Manajemen Kamar Hotel
Nama: [Nama Anda]
NIM: [NIM Anda]

## Deskripsi Project
API untuk manajemen kamar hotel dengan fitur CRUD (Create, Read, Update, Delete) menggunakan PHP dan MySQL.

## Query SQL Pembuatan Tabel 